<?php
$server = "localhost";
$user = "root";
$password = "";
$db = "herramientas";

$conn = mysqli_connect($server, $user, $password, $db);

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>
