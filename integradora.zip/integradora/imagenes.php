<?php
include 'db_conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vista1 = $_POST['vista1'];
    $vista2 = $_POST['vista2'];
    $vista3 = $_POST['vista3'];

    $sql = "INSERT INTO imagen (vista1, vista2, vista3) VALUES ('$vista1', '$vista2', '$vista3')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Imagenes agregadas correctamente";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<form method="post">
    <input type="text" name="vista1" placeholder="URL Vista 1" required>
    <input type="text" name="vista2" placeholder="URL Vista 2" required>
    <input type="text" name="vista3" placeholder="URL Vista 3" required>
    <button type="submit">Agregar Imagen</button>
</form>
