<?php
include 'db_conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];

    $sql = "INSERT INTO categoria (nombre) VALUES ('$nombre')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Categoría agregada correctamente";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<form method="post">
    <input type="text" name="nombre" placeholder="Nombre de la categoría" required>
    <button type="submit">Agregar Categoría</button>
</form>
