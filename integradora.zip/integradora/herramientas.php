<?php
include 'db_conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $existencias = $_POST['existencias'];
    $id_imagen = $_POST['id_imagen'];
    $id_categoria = $_POST['id_categoria'];

    $sql = "INSERT INTO herramientas (nombre, descripcion, precio, existencias, id_imagen, id_categoria) 
            VALUES ('$nombre', '$descripcion', '$precio', '$existencias', '$id_imagen', '$id_categoria')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Herramienta agregada correctamente";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<form method="post">
    <input type="text" name="nombre" placeholder="Nombre de la herramienta" required>
    <textarea name="descripcion" placeholder="Descripción"></textarea>
    <input type="number" name="precio" placeholder="Precio" step="0.01" required>
    <input type="number" name="existencias" placeholder="Existencias" required>
    <input type="number" name="id_imagen" placeholder="ID de imagen" required>
    <input type="number" name="id_categoria" placeholder="ID de categoría" required>
    <button type="submit">Agregar Herramienta</button>
</form>
