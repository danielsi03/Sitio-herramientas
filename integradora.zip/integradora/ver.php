<?php
include 'db_conexion.php';

$sql = "SELECT h.id, h.nombre, h.descripcion, h.precio, h.existencias, 
               i.vista1, i.vista2, i.vista3, 
               c.nombre AS categoria
        FROM herramientas h
        JOIN imagen i ON h.id_imagen = i.id
        JOIN categoria c ON h.id_categoria = c.id";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Existencias</th>
                <th>Vista 1</th>
                <th>Vista 2</th>
                <th>Vista 3</th>
                <th>Categoría</th>
            </tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['nombre']}</td>
                <td>{$row['descripcion']}</td>
                <td>{$row['precio']}</td>
                <td>{$row['existencias']}</td>
                <td><img src='{$row['vista1']}' width='100'></td>
                <td><img src='{$row['vista2']}' width='100'></td>
                <td><img src='{$row['vista3']}' width='100'></td>
                <td>{$row['categoria']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No hay herramientas registradas.";
}

mysqli_close($conn);
?>
